import pandas as pd
import psycopg
from databricks.sdk import WorkspaceClient
import streamlit as st
import os

def get_connection(w: WorkspaceClient, host: str, database: str, user: str) -> psycopg.Connection:
    """Get a connection to the Lakebase database using OAuth token."""
    user_token = st.context.headers.get("x-forwarded-access-token")
    user_email = st.context.headers.get("x-forwarded-email")
    
    return psycopg.connect(
        host=host,
        port=5432,
        dbname=database,
        user=user_email,
        password=user_token,
        sslmode="require",
    )


def query_df(w: WorkspaceClient, host: str, database: str, user: str, sql: str, params=None) -> pd.DataFrame:
    """Execute a SQL query and return results as a DataFrame."""
    conn = get_connection(w, host, database, user)
    try:
        with conn.cursor() as cur:
            cur.execute(sql, params=params)
            if not cur.description:
                return pd.DataFrame()
            
            cols = [d.name for d in cur.description]
            rows = cur.fetchall()
            return pd.DataFrame(rows, columns=cols)
    finally:
        conn.close()


def get_optimization_result(w: WorkspaceClient, host: str, database: str, user: str, run_id: str) -> pd.DataFrame:
    """Fetch optimization result by run_id from Lakehouse (Lakehouse Lakebase)."""
    sql = f"SELECT * FROM {os.getenv('SCHEMA')}.synced_sim WHERE id = '{run_id}'"
    df = query_df(w, host, database, user, sql)
    return df

