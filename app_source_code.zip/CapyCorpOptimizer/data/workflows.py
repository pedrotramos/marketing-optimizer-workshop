from databricks.sdk import WorkspaceClient
from typing import Dict, Any, Optional
import json
import os

def optimize_budget(
    total_budget: float,
    baseline_profit: float,
    constraints: dict,
    baseline_spend: dict,
    w: Optional[WorkspaceClient] = None,
    job_id: Optional[str] = None,
) -> dict:
    """
    Optimize marketing budget by running a Databricks workflow.
    
    Args:
        total_budget: Total budget to allocate
        constraints: Dictionary of channel constraints with min/max percentages
        w: Databricks WorkspaceClient (required if using workflow)
        job_id: Databricks job ID for the optimization workflow
        warehouse_id: SQL warehouse ID for retrieving results
    
    Returns:
        Dictionary with optimized allocation and metrics
    """
    # Configure os job parameters. DICA: Todos os campos devem ser do tipo STRING.
    job_parameters = {}

    run_response = None # Configure a chamada de execução do Job.

    return {
        "run_id": run_response.run_id,
        "status": "RUNNING",
        "workflow_triggered": True
    }

def check_workflow_status(w: WorkspaceClient, run_id: int) -> Dict[str, Any]:
    """
    Check the status of a Databricks workflow run.
    
    Args:
        w: Databricks workspace client
        run_id: Databricks job run ID
    
    Returns:
        dict: Status information with 'state', 'result_state', and 'message'
    """
    try:
        run_info = w.jobs.get_run(run_id=run_id)
        return {
            "state": run_info.state.life_cycle_state,
            "result_state": run_info.state.result_state if run_info.state.result_state else None,
            "message": run_info.state.state_message if run_info.state.state_message else None
        }
    except Exception as e:
        return {
            "state": "UNKNOWN",
            "result_state": None,
            "message": str(e)
        }