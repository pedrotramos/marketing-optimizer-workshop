import os
from databricks import sql
from databricks.sdk.core import Config
import pandas as pd
from databricks.sdk import WorkspaceClient
from typing import Any
import streamlit as st

def get_connection():
    user_token = st.context.headers.get("x-forwarded-access-token")
    # Crie a nova conexão com o Databricks SQL abaixo

def read_table(query, conn):
    with conn.cursor() as cursor:
        cursor.execute(query)
        return cursor.fetchall_arrow().to_pandas()

def get_historical_investments(w: WorkspaceClient) -> pd.DataFrame:
    """
    Get historical investments data from Databricks.
    
    Args:
        w: Databricks workspace client
    
    Returns:
        pd.DataFrame: DataFrame with correct data types
    """
    query = f"SELECT * FROM {os.getenv('CATALOG')}.{os.getenv('SCHEMA')}.investimentos"
    
    df = read_table(query, get_connection())
    return df


def get_historical_profits(w: WorkspaceClient) -> pd.DataFrame:
    """
    Get historical profits data from Databricks.
    
    Args:
        w: Databricks workspace client
    
    Returns:
        pd.DataFrame: DataFrame with correct data types
    """
    query = f"SELECT * FROM {os.getenv('CATALOG')}.{os.getenv('SCHEMA')}.lucro_bruto"
    
    df = read_table(query, get_connection())
    return df


def get_simulations_history(w: WorkspaceClient) -> pd.DataFrame:
    query = f"SELECT * FROM {os.getenv('CATALOG')}.{os.getenv('SCHEMA')}.resultados_simulacao"
    
    df = read_table(query, get_connection())
    return df