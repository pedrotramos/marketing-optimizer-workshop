import os
import streamlit as st
from datetime import date
from databricks.sdk import WorkspaceClient
from databricks.sdk.core import Config
from dotenv import load_dotenv

st.set_page_config(
    page_title="CapyCorp - Marketing Budget Optimizer",
    page_icon="🦫",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
    [data-testid="stMetric"] {
        background-color: #1E3A5F;
        padding: 15px 20px;
        border-radius: 10px;
        color: white;
    }
    [data-testid="stMetric"] label {
        color: rgba(255, 255, 255, 0.8) !important;
    }
    [data-testid="stMetric"] [data-testid="stMetricValue"] {
        color: white !important;
    }
    [data-testid="stMetric"] [data-testid="stMetricDelta"] {
        color: #90EE90 !important;
    }
    [data-testid="stMetric"] [data-testid="stMetricDelta"] svg {
        fill: #90EE90 !important;
    }
    .sidebar-logo {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 0;
        margin-bottom: 10px;
    }
    .sidebar-logo img {
        border-radius: 10px;
    }
    .sidebar-title {
        font-size: 1.5rem;
        font-weight: bold;
        color: #1E3A5F;
        margin: 0;
    }
    .sidebar-subtitle {
        font-size: 0.85rem;
        color: #666;
        margin: 0;
    }
    .nav-button {
        width: 100%;
        padding: 12px 16px;
        margin: 4px 0;
        border: none;
        border-radius: 8px;
        text-align: left;
        cursor: pointer;
        transition: all 0.2s;
    }
    .nav-button-active {
        background-color: #1E3A5F;
        color: white;
    }
    .nav-button-inactive {
        background-color: #f0f2f6;
        color: #1E3A5F;
    }
    .nav-button-inactive:hover {
        background-color: #e0e2e6;
    }
</style>
""", unsafe_allow_html=True)

from views import dashboard, simulation, history

load_dotenv()
cfg = Config(host=os.getenv("DATABRICKS_HOST"))
w = WorkspaceClient(config=cfg)

import logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger("databricks.sql.thrift_backend")
logger.setLevel(logging.DEBUG)

PAGES = {
    "Dashboard": {"module": dashboard, "icon": "📊"},
    "Simulação": {"module": simulation, "icon": "🎯"},
    "Histórico": {"module": history, "icon": "📋"},
}

if "current_page" not in st.session_state:
    st.session_state.current_page = "Dashboard"

with st.sidebar:
    st.markdown("""
    <div class="sidebar-logo">
        <img src="https://api.dicebear.com/7.x/bottts/svg?seed=capycorp&backgroundColor=b6e3f4" width="60">
        <div>
            <p class="sidebar-title">CapyCorp</p>
            <p class="sidebar-subtitle">Budget Optimizer</p>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("---")
    
    st.markdown("##### Menu")
    
    for page_name, page_info in PAGES.items():
        if st.button(
            f"{page_info['icon']} {page_name}",
            key=f"nav_{page_name}",
            use_container_width=True,
            type="primary" if st.session_state.current_page == page_name else "secondary"
        ):
            st.session_state.current_page = page_name
            st.rerun()
    
    st.markdown("---")
    
    st.caption(f"CapyCorp {date.today().year}")

PAGES[st.session_state.current_page]["module"].render(w)
