import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import os
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.jobs import RunLifeCycleState, RunResultState
from data.dbsql import (
    get_historical_investments,
    get_historical_profits,
    get_simulations_history
)
from data.workflows import optimize_budget, check_workflow_status
from data.lakebase import get_optimization_result


def format_currency(value):
    if value >= 1_000_000:
        return f"R$ {value/1_000_000:.1f}M"
    elif value >= 1_000:
        return f"R$ {value/1_000:.1f}K"
    return f"R$ {value:.0f}"


def round_to_largest_unit(value):
    """Round a value to its largest unit (millions, thousands, etc.)"""
    if value >= 1_000_000:
        # Round to nearest 100,000 (0.1M precision)
        return round(value / 100_000) * 100_000
    elif value >= 1_000:
        # Round to nearest 10,000 (0.01M or 10K precision)
        return round(value / 10_000) * 10_000
    else:
        # Round to nearest 1,000
        return round(value / 1_000) * 1_000


def render(w: WorkspaceClient):
    st.title("Simulação de Budget")
    st.markdown("### Otimize a alocação para maximizar o lucro bruto")
    
    historical_investments_df = get_historical_investments(w=w)
    historical_profits_df = get_historical_profits(w=w)
    channels = historical_investments_df["canal"].unique()
    
    total_current_budget = round_to_largest_unit(
        historical_investments_df[historical_investments_df["data"].dt.year == 2025]["investimento"].sum()
    )
    total_profit = historical_profits_df[historical_profits_df["data"].dt.year == 2025]["lucro_bruto"].sum()
    
    if "simulation_result" not in st.session_state:
        st.session_state.simulation_result = pd.DataFrame()
    if "workflow_run_id" not in st.session_state:
        st.session_state.workflow_run_id = None
    if "constraints" not in st.session_state:
        st.session_state.constraints = {
            channel: {"min": -30, "max": 30}
            for channel in channels
        }
    if "baseline_channel_spend" not in st.session_state:
        st.session_state.baseline_channel_spend = {
            channel: 0
            for channel in channels
        }
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.subheader("Configurações")
        
        total_budget = st.number_input(
            "Budget Total (R$)",
            min_value=50000.0,
            max_value=50000000.0,
            value=float(total_current_budget),
            step=50000.0,
            format="%.2f"
        )
        
        budget_diff = total_budget - total_current_budget
        budget_diff_pct = (budget_diff / total_current_budget) * 100 if total_current_budget > 0 else 0
        
        if budget_diff != 0:
            color = "green" if budget_diff > 0 else "red"
            st.markdown(
                f"<span style='color: {color}'>Variação: {format_currency(budget_diff)} ({budget_diff_pct:+.1f}%)</span>",
                unsafe_allow_html=True
            )
        
        st.markdown("---")
        
        st.subheader("Limites por Canal")
        st.caption("Define a variação percentual permitida em relação ao budget atual")
        
        apply_all = st.checkbox("Aplicar mesmos limites para todos")
        
        if apply_all:
            col_min, col_max = st.columns(2)
            with col_min:
                global_min = st.slider("Min. Global (%)", -50, 0, -30, key="global_min")
            with col_max:
                global_max = st.slider("Max. Global (%)", 0, 100, 30, key="global_max")
            
            for channel in channels:
                st.session_state.constraints[channel] = {
                    "min": global_min,
                    "max": global_max
                }
        else:
            for channel in channels:
                current_budget = historical_investments_df[(historical_investments_df["data"].dt.year == 2025) & (historical_investments_df["canal"] == channel)]["investimento"].sum()
                perf = historical_investments_df.merge(historical_profits_df, on=["canal", "data"], how="inner")
                perf = perf[perf["data"].dt.year == 2025].drop(columns=["data"]).groupby(by="canal").sum().reset_index()
                perf["retorno"] = perf["lucro_bruto"] / perf["investimento"]
                
                with st.expander(
                    f"{channel.replace('_', ' ').title()} - {format_currency(current_budget)} (Retorno: {perf[perf['canal'] == channel]['retorno'].sum():.2f}x)"
                ):
                    col_min, col_max = st.columns(2)
                    
                    with col_min:
                        min_val = st.slider(
                            "Min (%)",
                            -50, 0,
                            st.session_state.constraints[channel]["min"],
                            key=f"min_{channel}"
                        )
                    
                    with col_max:
                        max_val = st.slider(
                            "Max (%)",
                            0, 100,
                            st.session_state.constraints[channel]["max"],
                            key=f"max_{channel}"
                        )
                    
                    st.session_state.constraints[channel] = {
                        "min": min_val,
                        "max": max_val
                    }

                    st.session_state.baseline_channel_spend[channel] = float(current_budget)
                    
                    min_budget = float(current_budget) * (1 + min_val/100)
                    max_budget = float(current_budget) * (1 + max_val/100)
                    st.text(f"Range: {format_currency(min_budget)} - {format_currency(max_budget)}")
        
        st.markdown("---")
        
        if st.button("Executar Otimização", type="primary", use_container_width=True):
            job_id = os.getenv("JOB_ID")
            # Trigger Databricks workflow
            with st.spinner("Iniciando workflow de otimização..."):
                workflow_response = optimize_budget(
                    total_budget,
                    total_profit,
                    st.session_state.constraints,
                    st.session_state.baseline_channel_spend,
                    w=w,
                    job_id=job_id,
                )
                if workflow_response.get("workflow_triggered"):
                    st.session_state.workflow_run_id = workflow_response.get("run_id")
                    st.session_state.simulation_result = pd.DataFrame()
                    st.success(f"Workflow iniciado! Run ID: {workflow_response.get('run_id')}")
                    st.rerun()
    
    with col2:
        st.subheader("Alocação Atual vs. Otimizada")
        
        # Check workflow status and poll for results if workflow is running
        if st.session_state.workflow_run_id:
            workflow_status = check_workflow_status(w, st.session_state.workflow_run_id)
            
            if workflow_status["state"] == RunLifeCycleState.RUNNING:
                st.info(f"⏳ Workflow em execução... (Run ID: {st.session_state.workflow_run_id})")
                if st.button("🔄 Verificar Status", key="check_workflow_status", use_container_width=True):
                    st.rerun()
                # Auto-refresh hint
                st.caption("💡 Dica: Clique em 'Verificar Status' periodicamente.")
            elif workflow_status["state"] == RunLifeCycleState.TERMINATED:
                if workflow_status["result_state"] == RunResultState.SUCCESS:
                    # Try to retrieve results from table
                    result = get_optimization_result(w, os.getenv("PGHOST"), os.getenv("PGDATABASE"), os.getenv("PGUSER"), st.session_state.workflow_run_id)
                    if not result.empty:
                        st.session_state.simulation_result = result
                        st.session_state.workflow_run_id = None
                        st.success("✅ Otimização concluída! Resultados carregados da tabela.")
                        st.rerun()
                    else:
                        st.warning("⚠️ Workflow concluído, mas resultados ainda não estão disponíveis na tabela. O workflow pode estar processando os resultados.")
                        if st.button("🔄 Tentar Novamente", key="retry_results", use_container_width=True):
                            st.rerun()
                else:
                    st.error(f"❌ Workflow falhou: {workflow_status.get('message', 'Erro desconhecido')}")
                    if st.button("🔄 Limpar Status", key="clear_failed_workflow"):
                        st.session_state.workflow_run_id = None
                        st.rerun()
            else:
                st.warning(f"⚠️ Status do workflow: {workflow_status['state']}")
                if st.button("🔄 Verificar Novamente", key="check_status_again"):
                    st.rerun()
        
        if not st.session_state.simulation_result.empty:
            result = st.session_state.simulation_result

            growth_profit = (float(result["lucro_bruto"].iloc[0]) / float(total_profit)) - 1
            growth_investment = (float(result["investimento_total"].iloc[0]) / float(total_budget)) - 1
            
            st.markdown("#### Resultado da Otimização")
            
            m_col1, m_col2 = st.columns(2)
            
            with m_col1:
                st.metric(
                    "Investimento Total",
                    format_currency(float(result["investimento_total"].iloc[0])),
                    f"{growth_investment:+.2f}%"
                )
            
            with m_col2:
                st.metric(
                    "Lucro Bruto Projetado",
                    format_currency(float(result["lucro_bruto"].iloc[0])),
                    f"{growth_profit:+.2f}%"
                )
            
            st.markdown("---")
            
            comparison_data = []
            for channel in channels:
                # Channels are now strings (e.g., "google_ads"), not objects
                channel_name = channel.replace("_", " ").title()
                current = float(historical_investments_df[(historical_investments_df["data"].dt.year == 2025) & (historical_investments_df["canal"] == channel)]["investimento"].sum())
                optimized = float(result["investimento_por_canal"].iloc[0].get(channel, 0))
                diff = optimized - current
                diff_pct = (diff / current * 100) if current > 0 else 0
                
                comparison_data.append({
                    "Canal": channel_name,
                    "channel_id": channel,
                    "Atual": current,
                    "Otimizado": optimized,
                    "Diferenca": diff,
                    "Variacao (%)": diff_pct
                })
            
            comparison_df = pd.DataFrame(comparison_data)
            
            fig = go.Figure()
            
            fig.add_trace(go.Bar(
                name="Budget Atual",
                x=comparison_df["Canal"],
                y=comparison_df["Atual"],
                marker_color="#636EFA",
                text=[format_currency(v) for v in comparison_df["Atual"]],
                textposition="auto"
            ))
            
            fig.add_trace(go.Bar(
                name="Budget Otimizado",
                x=comparison_df["Canal"],
                y=comparison_df["Otimizado"],
                marker_color="#00CC96",
                text=[format_currency(v) for v in comparison_df["Otimizado"]],
                textposition="auto"
            ))
            
            fig.update_layout(
                title="Comparação de Alocação de Budget",
                barmode="group",
                xaxis_tickangle=-45,
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
                height=400
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            st.markdown("#### Detalhes da Alocação")
            
            display_data = []
            for item in comparison_data:
                display_data.append({
                    "Canal": item["Canal"],
                    "Atual": format_currency(item["Atual"]),
                    "Otimizado": format_currency(item["Otimizado"]),
                    "Diferenca": f"+{format_currency(item['Diferenca'])}" if item['Diferenca'] > 0 else f"-{format_currency(-item['Diferenca'])}",
                    "Variacao (%)": f"{item['Variacao (%)']:+.1f}%"
                })
            
            display_df = pd.DataFrame(display_data)
            st.dataframe(display_df, use_container_width=True, hide_index=True)
            
            st.markdown("---")
            
            # Sort dataframe by channel name for consistent ordering
            comparison_df_sorted = comparison_df.sort_values("Canal").copy()
            
            # Create consistent color mapping for channels (sorted order)
            color_palette = px.colors.qualitative.Set2
            sorted_channels = sorted(comparison_df["Canal"].unique())
            channel_colors = {
                channel_name: color_palette[i % len(color_palette)]
                for i, channel_name in enumerate(sorted_channels)
            }
            
            col_pie1, col_pie2 = st.columns(2)
            
            with col_pie1:
                fig_current = px.pie(
                    comparison_df_sorted,
                    values="Atual",
                    names="Canal",
                    title="Distribuição Atual",
                    hole=0.4,
                    color="Canal",
                    color_discrete_map=channel_colors,
                    category_orders={"Canal": sorted_channels}
                )
                fig_current.update_traces(textposition="inside", textinfo="label+percent")
                fig_current.update_layout(showlegend=False, height=450)
                st.plotly_chart(fig_current, use_container_width=True)
            
            with col_pie2:
                fig_optimized = px.pie(
                    comparison_df_sorted,
                    values="Otimizado",
                    names="Canal",
                    title="Distribuição Otimizada",
                    hole=0.4,
                    color="Canal",
                    color_discrete_map=channel_colors,
                    category_orders={"Canal": sorted_channels}
                )
                fig_optimized.update_traces(textposition="inside", textinfo="label+percent")
                fig_optimized.update_layout(showlegend=False, height=450)
                st.plotly_chart(fig_optimized, use_container_width=True)
        
        else:
            st.info("Configure os parâmetros e clique em 'Executar Otimização' para ver os resultados.")
            
            st.markdown("#### Alocação Atual")
            
            current_data = []
            for channel in channels:
                budget_value = historical_investments_df[(historical_investments_df["data"].dt.year == 2025) & (historical_investments_df["canal"] == channel)]["investimento"].sum()
                current_data.append({
                    "Canal": f"{channel.replace('_', ' ').title()}",
                    "Budget": budget_value
                })
            
            current_df = pd.DataFrame(current_data)
            
            fig = px.bar(
                current_df,
                x="Canal",
                y="Budget",
                color="Budget",
                color_continuous_scale="Blues",
            )
            fig.update_layout(xaxis_tickangle=-45, showlegend=False)
            fig.update_yaxes(range=[0, current_df["Budget"].max()])
            
            st.plotly_chart(fig, use_container_width=True)
            
            st.markdown("#### Retorno por Canal")

            perf = historical_investments_df.merge(historical_profits_df, on=["canal", "data"], how="inner")
            perf = perf[perf["data"].dt.year == 2025].drop(columns=["data"]).groupby(by="canal").sum().reset_index()
            perf["retorno"] = perf["lucro_bruto"] / perf["investimento"]
            
            perf_data = []
            for channel in channels:
                perf_data.append({
                    "Canal": channel.replace("_", " ").title(),
                    "Retorno": perf[perf['canal'] == channel]['retorno'].sum(),
                })
            
            perf_df = pd.DataFrame(perf_data)
            
            fig = px.bar(
                perf_df,
                x="Canal",
                y="Retorno",
                color="Retorno",
                color_continuous_scale="Blues",
            )
            fig.update_layout(xaxis_tickangle=-45, showlegend=False, height=350)
            
            st.plotly_chart(fig, use_container_width=True)
