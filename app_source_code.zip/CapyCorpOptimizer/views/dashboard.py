import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from dotenv import load_dotenv
import pandas as pd
from databricks.sdk import WorkspaceClient
from data.dbsql import (
    get_historical_investments,
    get_historical_profits
)

def format_currency(value):
    if value >= 1_000_000:
        return f"R$ {value/1_000_000:.1f}M"
    elif value >= 1_000:
        return f"R$ {value/1_000:.1f}K"
    return f"R$ {value:.0f}"


def calculate_variation(current, previous):
    if previous == 0:
        return 0
    return ((current - previous) / previous) * 100


def render(w: WorkspaceClient):
    st.title("Dashboard de Marketing")
    st.markdown(f"### CapyCorp - Visão Geral de Performance 2025")
    
    historical_investments_df = get_historical_investments(w=w)
    historical_profits_df = get_historical_profits(w=w)
    channels = historical_investments_df["canal"].unique()
    
    current_year_investments = historical_investments_df[historical_investments_df["data"].dt.year == 2025]["investimento"].sum()
    previous_year_investments = historical_investments_df[historical_investments_df["data"].dt.year == 2024]["investimento"].sum()
    current_year_profits = historical_profits_df[historical_profits_df["data"].dt.year == 2025]["lucro_bruto"].sum()
    previous_year_profits = historical_profits_df[historical_profits_df["data"].dt.year == 2024]["lucro_bruto"].sum()
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        spend_var = calculate_variation(current_year_investments, previous_year_investments)
        st.metric(
            label="Investimento Total ",
            value=format_currency(current_year_investments),
            delta=f"{spend_var:+.1f}%"
        )
    
    with col2:
        profit_var = calculate_variation(current_year_profits, previous_year_profits)
        st.metric(
            label="Lucro Bruto",
            value=format_currency(current_year_profits),
            delta=f"{profit_var:+.1f}%"
        )
    
    with col3:
        margin_var = calculate_variation(current_year_profits / current_year_investments, previous_year_profits / previous_year_investments)
        st.metric(
            label="Retorno",
            value=f"{(current_year_profits / current_year_investments):.2f}x",
            delta=f"{margin_var:+.1f}%"
        )
    
    st.markdown("---")
    
    st.subheader("Evolução dos Indicadores")
    
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    
    fig.add_trace(
        go.Scatter(
            x=historical_profits_df[historical_profits_df["data"].dt.year == 2025]["data"].unique(),
            y=historical_profits_df[historical_profits_df["data"].dt.year == 2025].groupby(by="data")["lucro_bruto"].sum(),
            name="Lucro Bruto",
            line=dict(color="#2E86AB", width=3),
            fill="tozeroy",
            fillcolor="rgba(46, 134, 171, 0.1)"
        ),
        secondary_y=False
    )
    
    fig.add_trace(
        go.Scatter(
            x=historical_investments_df[historical_investments_df["data"].dt.year == 2025]["data"].unique(),
            y=historical_investments_df[historical_investments_df["data"].dt.year == 2025].groupby(by="data")["investimento"].sum(),
            name="Investimento",
            line=dict(color="#A23B72", width=3, dash="dot")
        ),
        secondary_y=True
    )
    
    fig.update_layout(
        title="Lucro Bruto e Investimento ao Longo de 2025",
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    fig.update_yaxes(title_text="Lucro Bruto (R$)", secondary_y=False)
    fig.update_yaxes(title_text="Investimento (R$)", secondary_y=True, showgrid=False)
    
    st.plotly_chart(fig, use_container_width=True)
    
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Alocação Atual de Budget")
        
        allocation_data = []
        for channel in channels:
            allocation_data.append({
                "Canal": channel.replace("_", " ").title(),
                "Budget": historical_investments_df[(historical_investments_df["data"].dt.year == 2025) & (historical_investments_df["canal"] == channel)]["investimento"].sum(),
            })
        
        allocation_df = pd.DataFrame(allocation_data)
        
        fig = px.pie(
            allocation_df,
            values="Budget",
            names="Canal",
            hole=0.4,
            color_discrete_sequence=px.colors.qualitative.Set2
        )
        fig.update_traces(textposition="inside", textinfo="percent+label")
        fig.update_layout(showlegend=False)
        
        st.plotly_chart(fig, use_container_width=True)    
    with col2:
        st.subheader("Retorno por Canal")
        
        perf = historical_investments_df.merge(historical_profits_df, on=["canal", "data"], how="inner")
        perf = perf[perf["data"].dt.year == 2025].drop(columns=["data"]).groupby(by="canal").sum().reset_index()
        perf["retorno"] = perf["lucro_bruto"] / perf["investimento"]

        performance_data = []
        for channel in channels:
            budget = historical_investments_df[(historical_investments_df["data"].dt.year == 2025) & (historical_investments_df["canal"] == channel)]["investimento"].sum()
            
            performance_data.append({
                "Canal": channel.replace("_", " ").title(),
                "Retorno": perf[perf["canal"] == channel]["retorno"].sum(),
                "Budget": format_currency(budget),
            })
        
        perf_df = pd.DataFrame(performance_data)
        
        fig = px.bar(
            perf_df,
            x="Canal",
            y="Retorno",
            color="Retorno",
            color_continuous_scale="RdYlGn",
        )
        fig.update_layout(xaxis_tickangle=-45, showlegend=False)
        
        st.plotly_chart(fig, use_container_width=True)
    
    st.markdown("---")
    
    st.subheader("Detalhes por Canal")
    
    details_data = []
    for channel in channels:
        budget = historical_investments_df[(historical_investments_df["data"].dt.year == 2025) & (historical_investments_df["canal"] == channel)]["investimento"].sum()
        profit = budget * (perf[perf["canal"] == channel]["retorno"])
        
        details_data.append({
            "Canal": channel.replace("_", " ").title(),
            "Budget Anual": format_currency(budget),
            "Lucro Bruto Estimado": format_currency(profit.sum()),
            "Retorno": "{:.2f}x".format(perf[perf["canal"] == channel]["retorno"].sum()),
        })
    
    details_df = pd.DataFrame(details_data)
    st.dataframe(details_df, use_container_width=True, hide_index=True)
    
    st.markdown("---")
    
    st.subheader("Evolução por Canal")
    
    channel_hist = historical_investments_df.merge(historical_profits_df, on=["data", "canal"], how="inner")
    channel_hist["canal"] = channel_hist["canal"].str.replace("_", " ").str.title()
    channel_hist = channel_hist[channel_hist["data"].dt.year == 2025]
    
    selected_metric = st.selectbox(
        "Selecione a métrica:",
        ["lucro_bruto", "investimento"],
        format_func=lambda x: {
            "lucro_bruto": "Lucro Bruto",
            "investimento": "Investimento",
        }.get(x, x)
    )
    
    fig = px.line(
        channel_hist,
        x="data",
        y=selected_metric,
        color="canal",
        title=f"Evolucao de {selected_metric.replace('_', ' ').title()} por Canal",
        markers=True
    )
    fig.update_layout(
        legend=dict(orientation="h", yanchor="bottom", y=-0.3, xanchor="center", x=0.5),
        hovermode="x unified"
    )
    fig.update_yaxes(title_text=f"{selected_metric.replace('_', ' ').title()} (R$)")
    
    st.plotly_chart(fig, use_container_width=True)
