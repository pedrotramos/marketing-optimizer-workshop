import os
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
from databricks.sdk import WorkspaceClient
from datetime import datetime
from data.dbsql import get_historical_investments, get_historical_profits, get_simulations_history
from data.lakebase import get_optimization_result


def format_currency(value):
    if value >= 1_000_000:
        return f"R$ {value/1_000_000:.1f}M"
    elif value >= 1_000:
        return f"R$ {value/1_000:.1f}K"
    return f"R$ {value:.0f}"


def format_date(date_str):
    dt = datetime.fromisoformat(date_str)
    return dt.strftime("%d/%m/%Y %H:%M")


def render(w: WorkspaceClient):
    st.title("Histórico de Simulações")
    st.markdown("### Visualize e compare simulações anteriores")
    
    simulations = get_simulations_history(w=w)
    historical_investments = get_historical_investments(w=w)
    historical_profits = get_historical_profits(w=w)
    profit_2025 = historical_profits[historical_profits["data"].dt.year == 2025]["lucro_bruto"].sum()
    channels = historical_investments[historical_investments["data"].dt.year == 2025]["canal"].unique()
    
    if simulations.empty:
        st.warning("Nenhuma simulação encontrada. Execute uma simulação na pagina de Simulação.")
        return
    
    tab1, tab2 = st.tabs(["Lista de Simulações", "Comparar Simulações"])
    
    with tab1:
        st.subheader("Simulações Realizadas")
        sim_data = []
        for _, row in simulations.iterrows():
            improvement = (row["lucro_bruto"] / float(profit_2025)) - 1
            projected = row["lucro_bruto"]
            sim_data.append({
                "ID": row["id"],
                "Budget Total": format_currency(row["investimento_total"]),
                "Lucro Projetado": format_currency(projected),
                "Melhoria": f"{improvement:+.2f}%",
            })
        
        sim_df = pd.DataFrame(sim_data)
        st.dataframe(sim_df, use_container_width=True, hide_index=True)
        
        st.markdown("---")
        
        st.subheader("Detalhes da Simulação")
        
        sim_options = [f"{s}" for s in simulations["id"]]
        selected_sim_id = st.selectbox("Selecione uma simulação:", sim_options)
        
        if selected_sim_id:
            sim = get_optimization_result(w, os.getenv("PGHOST"), os.getenv("PGDATABASE"), os.getenv("PGUSER"), selected_sim_id)
            
            if not sim.empty:                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.metric("Budget Total", format_currency(sim["investimento_total"].iloc[0]))
                
                with col2:
                    st.metric("Lucro Projetado", format_currency(sim["lucro_bruto"].iloc[0]))
                
                st.markdown("---")
                
                comparison_data = []
                for channel in channels:
                    current = float(historical_investments[(historical_investments["data"].dt.year == 2025) & (historical_investments["canal"] == channel)]["investimento"].sum())
                    optimized = sim["investimento_por_canal"].iloc[0].get(channel, 0)
                    diff_pct = ((optimized - current) / current * 100) if current > 0 else 0
                    
                    comparison_data.append({
                        "Canal": channel.replace("_", " ").title(),
                        "Alocação Original": current,
                        "Alocação Otimizada": optimized,
                        "Variacao (%)": diff_pct
                    })
                
                comparison_df = pd.DataFrame(comparison_data)
                
                fig = go.Figure()
                
                fig.add_trace(go.Bar(
                    name="Original",
                    x=comparison_df["Canal"],
                    y=comparison_df["Alocação Original"],
                    marker_color="#636EFA"
                ))
                
                fig.add_trace(go.Bar(
                    name="Otimizado",
                    x=comparison_df["Canal"],
                    y=comparison_df["Alocação Otimizada"],
                    marker_color="#00CC96"
                ))
                
                fig.update_layout(
                    title="Alocação Original vs. Otimizada",
                    barmode="group",
                    xaxis_tickangle=-45,
                    height=400
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                display_data = []
                for item in comparison_data:
                    display_data.append({
                        "Canal": item["Canal"],
                        "Alocação Original": format_currency(item["Alocação Original"]),
                        "Alocação Otimizada": format_currency(item["Alocação Otimizada"]),
                        "Variacao (%)": f"{item['Variacao (%)']:+.1f}%"
                    })
                
                display_df = pd.DataFrame(display_data)
                st.dataframe(display_df, use_container_width=True, hide_index=True)
    
    with tab2:
        st.subheader("Comparar Simulações")
        
        if len(simulations) < 2:
            st.warning("Você precisa de pelo menos 2 simulações para fazer uma comparação.")
            return
        
        col1, col2 = st.columns(2)
        
        sim_options_list = [f"{s}" for s in simulations["id"]]
        
        with col1:
            sim1_id = st.selectbox("Simulação 1:", sim_options_list, index=0, key="compare_sim1")
        
        with col2:
            default_idx = 1 if len(sim_options_list) > 1 else 0
            sim2_id = st.selectbox("Simulação 2:", sim_options_list, index=default_idx, key="compare_sim2")
        
        if sim1_id and sim2_id:
            sim1 = get_optimization_result(w, os.getenv("PGHOST"), os.getenv("PGDATABASE"), os.getenv("PGUSER"), sim1_id)
            sim2 = get_optimization_result(w, os.getenv("PGHOST"), os.getenv("PGDATABASE"), os.getenv("PGUSER"), sim2_id)
            
            if (not sim1.empty) and (not sim2.empty):
                st.markdown("---")
                
                st.markdown("#### Comparação de Métricas")
                
                proj1 = sim1["lucro_bruto"].iloc[0]
                proj2 = sim2["lucro_bruto"].iloc[0]
                
                metrics_comparison = pd.DataFrame({
                    "Metrica": ["Budget Total", "Lucro Projetado"],
                    sim1["id"].iloc[0]: [
                        format_currency(sim1["investimento_total"].iloc[0]),
                        format_currency(proj1),
                    ],
                    sim2["id"].iloc[0]: [
                        format_currency(sim2["investimento_total"].iloc[0]),
                        format_currency(proj2),
                    ]
                })
                
                st.dataframe(metrics_comparison, use_container_width=True, hide_index=True)
                
                st.markdown("---")
                
                st.markdown("#### Comparação de Alocação")
                
                allocation_comparison = []
                for channel in channels:
                    alloc1 = sim1["investimento_por_canal"].iloc[0].get(channel, 0)
                    alloc2 = sim2["investimento_por_canal"].iloc[0].get(channel, 0)
                    diff = alloc2 - alloc1
                    
                    allocation_comparison.append({
                        "Canal": channel.replace("_", " ").title(),
                        sim1["id"].iloc[0]: alloc1,
                        sim2["id"].iloc[0]: alloc2,
                        "Diferença": diff
                    })
                
                alloc_df = pd.DataFrame(allocation_comparison)
                
                fig = go.Figure()
                
                fig.add_trace(go.Bar(
                    name=sim1["id"].iloc[0],
                    x=alloc_df["Canal"],
                    y=alloc_df[sim1["id"].iloc[0]],
                    marker_color="#636EFA"
                ))
                
                fig.add_trace(go.Bar(
                    name=sim2["id"].iloc[0],
                    x=alloc_df["Canal"],
                    y=alloc_df[sim2["id"].iloc[0]],
                    marker_color="#EF553B"
                ))
                
                fig.update_layout(
                    title="Alocação de Budget por Simulação",
                    barmode="group",
                    xaxis_tickangle=-45,
                    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
                    height=450
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                display_data = []
                for item in allocation_comparison:
                    display_data.append({
                        "Canal": item["Canal"],
                        sim1["id"].iloc[0]: format_currency(item[sim1["id"].iloc[0]]),
                        sim2["id"].iloc[0]: format_currency(item[sim2["id"].iloc[0]]),
                        "Diferença": f"+{format_currency(item['Diferença'])}" if item['Diferença'] > 0 else f"-{format_currency(-item['Diferença'])}"
                    })
                
                display_alloc_df = pd.DataFrame(display_data)
                st.dataframe(display_alloc_df, use_container_width=True, hide_index=True)
